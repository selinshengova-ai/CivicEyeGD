using CivicEyeGD.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using AdminDashboard = CivicEyeGD.Pages.Admin.IndexModel;

namespace CivicEyeGD.Tests;

/// <summary>
/// Таблото е единственото място, където общината променя данните.
/// Тук се пазят обещанията от документацията: всяка смяна на статуса
/// остава в историята с автор и бележка, административната намеса в
/// приоритета е ограничена, записването е с един бутон, а филтърът за
/// приключени сигнали наистина ги намира.
/// </summary>
public sealed class AdminWorkflowTests : IDisposable
{
    private readonly TestHost _host = new();

    [Fact]
    public async Task StatusChange_WritesHistoryTheCitizenCanRead()
    {
        var adminId = await _host.CreateAdministratorAsync("sluzhitel-1");
        var report = await OpenReportAsync();

        var result = await AdminPage(adminId).OnPostUpdateAsync(
            report.Id, ReportStatuses.InProgress, "Екипът е изпратен.", adjustment: 0, filterStatus: null);

        AssertSavedNotice(result, "saved");

        var entry = Assert.Single(await _host.Context.StatusHistories.ToListAsync());
        Assert.Equal(ReportStatuses.New, entry.OldStatus);
        Assert.Equal(ReportStatuses.InProgress, entry.NewStatus);
        Assert.Equal("Екипът е изпратен.", entry.Comment);
        Assert.Equal(adminId, entry.ChangedByUserId);
        Assert.Equal(report.Id, entry.ReportId);
    }

    // Един бутон за трите: служителят решава статуса, бележката и
    // намесата в приоритета в един момент, не на два пъти.
    [Fact]
    public async Task SingleSave_ChangesStatusAndAdjustmentTogether()
    {
        var adminId = await _host.CreateAdministratorAsync("sluzhitel-2");
        var report = await OpenReportAsync();

        await AdminPage(adminId).OnPostUpdateAsync(
            report.Id, ReportStatuses.InProgress, "Кръпката е в програмата.", adjustment: 7, filterStatus: null);

        var saved = await ReloadAsync(report.Id);

        Assert.Equal(ReportStatuses.InProgress, saved.Status);
        Assert.Equal(7, saved.AdminPriorityAdjustment);

        // Двете намеси са в един запис: историята е дневник на щракванията,
        // не на думите, и два реда за един бутон биха лъгали.
        var entry = Assert.Single(await _host.Context.StatusHistories.ToListAsync());
        Assert.Equal(ReportStatuses.New, entry.OldStatus);
        Assert.Equal(ReportStatuses.InProgress, entry.NewStatus);
        Assert.Equal(0, entry.OldPriorityAdjustment);
        Assert.Equal(7, entry.NewPriorityAdjustment);
    }

    [Fact]
    public async Task Save_WithoutAnythingDifferent_WritesNoHistoryAndSaysSo()
    {
        var adminId = await _host.CreateAdministratorAsync("sluzhitel-3");
        var report = await OpenReportAsync();

        var result = await AdminPage(adminId).OnPostUpdateAsync(
            report.Id, ReportStatuses.New, null, adjustment: 0, filterStatus: null);

        AssertSavedNotice(result, "unchanged");
        Assert.Empty(await _host.Context.StatusHistories.ToListAsync());
    }

    // Бележката е сама по себе си намеса: служителят обяснява какво е
    // видял, и гражданът трябва да може да прочете обяснението по-късно,
    // дори статусът и приоритетът да не са мърднати.
    [Fact]
    public async Task NoteWithoutAnyChange_IsStillRecordedInTheHistory()
    {
        var adminId = await _host.CreateAdministratorAsync("sluzhitel-4");
        var report = await OpenReportAsync();

        await AdminPage(adminId).OnPostUpdateAsync(
            report.Id, ReportStatuses.New, "Проверих мястото.", adjustment: 0, filterStatus: null);

        var entry = Assert.Single(await _host.Context.StatusHistories.ToListAsync());
        Assert.Equal("Проверих мястото.", entry.Comment);
        // Равните статуси казват на страницата: това не е преход.
        Assert.Equal(entry.OldStatus, entry.NewStatus);
        Assert.Null(entry.OldPriorityAdjustment);
        Assert.Null(entry.NewPriorityAdjustment);
    }

    // Корекцията на приоритета се записва, защото без нея числото на
    // таблото скоква без обяснение.
    [Fact]
    public async Task AdjustingOnlyThePriority_IsRecordedWithoutAStatusChange()
    {
        var adminId = await _host.CreateAdministratorAsync("sluzhitel-5");
        var report = await OpenReportAsync();

        await AdminPage(adminId).OnPostUpdateAsync(
            report.Id, ReportStatuses.New, null, adjustment: 5, filterStatus: null);

        Assert.Equal(5, (await ReloadAsync(report.Id)).AdminPriorityAdjustment);

        var entry = Assert.Single(await _host.Context.StatusHistories.ToListAsync());
        Assert.Equal(ReportStatuses.New, entry.OldStatus);
        Assert.Equal(ReportStatuses.New, entry.NewStatus);
        Assert.Equal(0, entry.OldPriorityAdjustment);
        Assert.Equal(5, entry.NewPriorityAdjustment);
    }

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("   ")]
    public async Task StatusChange_ToTheSameStatus_LeavesNoExtraEntry(string? comment)
    {
        var adminId = await _host.CreateAdministratorAsync("sluzhitel-6");
        var report = await OpenReportAsync();

        await AdminPage(adminId).OnPostUpdateAsync(
            report.Id, ReportStatuses.New, comment, adjustment: 0, filterStatus: null);

        Assert.Empty(await _host.Context.StatusHistories.ToListAsync());
    }

    [Fact]
    public async Task StatusChange_WithoutComment_StoresNoEmptyText()
    {
        var adminId = await _host.CreateAdministratorAsync("sluzhitel-6");
        var report = await OpenReportAsync();

        await AdminPage(adminId).OnPostUpdateAsync(
            report.Id, ReportStatuses.Resolved, "   ", adjustment: 0, filterStatus: null);

        var entry = Assert.Single(await _host.Context.StatusHistories.ToListAsync());
        Assert.Null(entry.Comment);
    }

    [Fact]
    public async Task StatusComment_LongerThanTheLimit_IsCut()
    {
        var adminId = await _host.CreateAdministratorAsync("sluzhitel-7");
        var report = await OpenReportAsync();

        await AdminPage(adminId).OnPostUpdateAsync(
            report.Id,
            ReportStatuses.Resolved,
            new string('а', AdminDashboard.MaxCommentLength + 120),
            adjustment: 0,
            filterStatus: null);

        var entry = Assert.Single(await _host.Context.StatusHistories.ToListAsync());
        Assert.Equal(AdminDashboard.MaxCommentLength, entry.Comment!.Length);
    }

    [Theory]
    [InlineData("Ще го оправим")]
    [InlineData("")]
    [InlineData(null)]
    public async Task StatusChange_WithUnknownStatus_IsRejected(string? newStatus)
    {
        var adminId = await _host.CreateAdministratorAsync("sluzhitel-8");
        var report = await OpenReportAsync();

        var badRequest = Assert.IsType<BadRequestObjectResult>(
            await AdminPage(adminId).OnPostUpdateAsync(
                report.Id, newStatus!, null, adjustment: 0, filterStatus: null));

        Assert.Equal("Непознат статус.", badRequest.Value);
        Assert.Equal(ReportStatuses.New, (await ReloadAsync(report.Id)).Status);
        Assert.Empty(await _host.Context.StatusHistories.ToListAsync());
    }

    [Fact]
    public async Task StatusChange_OnMissingReport_ReturnsNotFound()
    {
        var adminId = await _host.CreateAdministratorAsync("sluzhitel-9");

        Assert.IsType<NotFoundResult>(
            await AdminPage(adminId).OnPostUpdateAsync(
                id: 4242, ReportStatuses.Resolved, null, adjustment: 0, filterStatus: null));
    }

    // Проверката за корекцията е преди каквото и да е записване, затова
    // лош опит не оставя полузаписан статус зад гърба си.
    [Theory]
    [InlineData(-1)]
    [InlineData(11)]
    [InlineData(1000)]
    public async Task PriorityAdjustment_OutsideTheScale_IsRejected(int adjustment)
    {
        var adminId = await _host.CreateAdministratorAsync("sluzhitel-10");
        var report = await OpenReportAsync();

        var badRequest = Assert.IsType<BadRequestObjectResult>(
            await AdminPage(adminId).OnPostUpdateAsync(
                report.Id, ReportStatuses.Resolved, null, adjustment, filterStatus: null));

        Assert.Equal("Корекцията на приоритета е между 0 и 10.", badRequest.Value);
        Assert.Equal(ReportStatuses.New, (await ReloadAsync(report.Id)).Status);
        Assert.Equal(0, (await ReloadAsync(report.Id)).AdminPriorityAdjustment);
        Assert.Empty(await _host.Context.StatusHistories.ToListAsync());
    }

    [Fact]
    public async Task PriorityAdjustment_MovesTheScoreOnTheDashboard()
    {
        var adminId = await _host.CreateAdministratorAsync("sluzhitel-11");
        var report = await OpenReportAsync();
        var page = AdminPage(adminId);

        var before = page.PriorityOf(report);

        await page.OnPostUpdateAsync(
            report.Id, ReportStatuses.New, null, adjustment: 10, filterStatus: null);

        var after = page.PriorityOf(await ReloadAsync(report.Id));

        // Никакви оценки и потвърждения: 20/140 -> 30/140, т.е. 14.3 -> 21.4.
        Assert.Equal(14.3, before, 1);
        Assert.Equal(21.4, after, 1);
    }

    [Fact]
    public async Task Dashboard_ByDefaultListsOnlyActiveReports()
    {
        var adminId = await _host.CreateAdministratorAsync("sluzhitel-12");
        await SeedThreeStatusesAsync();

        var page = AdminPage(adminId);
        await page.OnGetAsync(filterStatus: null);

        Assert.Equal(1, page.TotalActiveCount);
        Assert.Equal(2, page.ClosedCount);
        Assert.Single(page.Reports);
        Assert.Equal("Активни сигнали", page.ListTitle);
    }

    [Fact]
    public async Task AfterSave_TheDashboardExplainsWhatHappened()
    {
        var adminId = await _host.CreateAdministratorAsync("sluzhitel-13");
        var page = AdminPage(adminId);

        await page.OnGetAsync(filterStatus: null, savedId: 12, notice: "saved");
        Assert.Equal("Промените по сигнал #12 са записани.", page.Notice);

        await page.OnGetAsync(filterStatus: null, savedId: 12, notice: "unchanged");
        Assert.Contains("не се промени", page.Notice);

        await page.OnGetAsync(filterStatus: null);
        Assert.Null(page.Notice);
    }

    [Fact]
    public async Task ClosedFilter_ListsBothResolvedAndRejected()
    {
        var adminId = await _host.CreateAdministratorAsync("sluzhitel-14");
        await SeedThreeStatusesAsync();

        var page = AdminPage(adminId);
        await page.OnGetAsync(AdminDashboard.ClosedFilter);

        Assert.Equal(2, page.Reports.Count);
        Assert.Equal("Приключени сигнали", page.ListTitle);
        Assert.Equal(AdminDashboard.ClosedFilter, page.FilterStatus);
    }

    [Fact]
    public async Task UnknownFilterValue_FallsBackToActiveReports()
    {
        var adminId = await _host.CreateAdministratorAsync("sluzhitel-15");
        await SeedThreeStatusesAsync();

        var page = AdminPage(adminId);
        await page.OnGetAsync("какво и да е");

        Assert.Equal(string.Empty, page.FilterStatus);
        Assert.Single(page.Reports);
    }

    // Изтриването е единственото админско действие, което не се връща:
    // затова тестовете проверяват не само реда в Reports, а и четирите
    // зависимите таблици, и файла на диска.
    [Fact]
    public async Task Delete_RemovesReportWithItsRowsAndItsImageFile()
    {
        var adminId = await _host.CreateAdministratorAsync("sluzhitel-16");
        var authorId = await _host.CreateUserAsync("avtor-za-iztrivane");

        var report = await _host.AddReportAsync(authorId, r => r.Title = "Дъска под крака");

        var stored = await _host.Storage.SaveAsync(FakeFiles.Jpeg());
        _host.Context.ReportImages.Add(new ReportImage
        {
            ReportId = report.Id,
            StoredFileName = stored.StoredFileName,
            ContentType = stored.ContentType,
            SizeBytes = stored.SizeBytes
        });

        var raterId = await _host.CreateUserAsync("ocenia-16");
        _host.Context.SeverityRatings.Add(new SeverityRating
        {
            ReportId = report.Id,
            UserId = raterId,
            Rating = 5
        });

        var voterId = await _host.CreateUserAsync("potvardi-16");
        _host.Context.Confirmations.Add(new Confirmation { ReportId = report.Id, UserId = voterId });

        _host.Context.StatusHistories.Add(new StatusHistory
        {
            ReportId = report.Id,
            OldStatus = ReportStatuses.New,
            NewStatus = ReportStatuses.Rejected,
            ChangedByUserId = adminId,
            Comment = "Не е от общината."
        });

        await _host.Context.SaveChangesAsync();

        Assert.NotNull(_host.Storage.GetFullPath(stored.StoredFileName));

        var result = await AdminPage(adminId).OnPostDeleteAsync(report.Id, filterStatus: null);

        var redirect = Assert.IsType<RedirectToPageResult>(result);
        Assert.Equal("deleted", redirect.RouteValues!["notice"]);
        Assert.Equal(report.Id, redirect.RouteValues!["deletedId"]);

        Assert.False(await _host.Context.Reports.AnyAsync(r => r.Id == report.Id));
        Assert.False(await _host.Context.ReportImages.AnyAsync(i => i.ReportId == report.Id));
        Assert.False(await _host.Context.SeverityRatings.AnyAsync(s => s.ReportId == report.Id));
        Assert.False(await _host.Context.Confirmations.AnyAsync(c => c.ReportId == report.Id));
        Assert.False(await _host.Context.StatusHistories.AnyAsync(h => h.ReportId == report.Id));

        // Файлът не е в нито една база: ако остане, дискът се пълни с
        // снимки, които никой не може вече да отвори през сигнала.
        Assert.Null(_host.Storage.GetFullPath(stored.StoredFileName));
    }

    [Fact]
    public async Task Delete_KeepsTheOtherReportsAndTheirHistory()
    {
        var adminId = await _host.CreateAdministratorAsync("sluzhitel-17");
        var authorId = await _host.CreateUserAsync("avtor-na-sosedite");

        var doomed = await _host.AddReportAsync(authorId, r => r.Title = "Този ще изчезне");
        var neighbour = await _host.AddReportAsync(authorId, r => r.Title = "Този остава");

        _host.Context.StatusHistories.Add(new StatusHistory
        {
            ReportId = neighbour.Id,
            OldStatus = ReportStatuses.New,
            NewStatus = ReportStatuses.InProgress,
            ChangedByUserId = adminId
        });
        await _host.Context.SaveChangesAsync();

        await AdminPage(adminId).OnPostDeleteAsync(doomed.Id, filterStatus: null);

        var page = AdminPage(adminId);
        await page.OnGetAsync(null);

        Assert.Equal("Този остава", Assert.Single(page.Reports).Title);
        Assert.Single(await _host.Context.StatusHistories.ToListAsync());
    }

    [Fact]
    public async Task Delete_UnknownReportIsNotFoundAndChangesNothing()
    {
        var adminId = await _host.CreateAdministratorAsync("sluzhitel-18");
        await OpenReportAsync();

        var result = await AdminPage(adminId).OnPostDeleteAsync(424242, filterStatus: null);

        Assert.IsType<NotFoundResult>(result);
        Assert.Single(await _host.Context.Reports.ToListAsync());
    }

    private static void AssertSavedNotice(IActionResult result, string expectedNotice)
    {
        var redirect = Assert.IsType<RedirectToPageResult>(result);

        Assert.Equal(expectedNotice, redirect.RouteValues!["notice"]);
        Assert.NotNull(redirect.RouteValues!["savedId"]);
    }

    private async Task<Report> OpenReportAsync()
    {
        var userId = await _host.CreateUserAsync("avtor-" + Guid.NewGuid().ToString("N")[..8]);
        return await _host.AddReportAsync(userId);
    }

    private async Task SeedThreeStatusesAsync()
    {
        var userId = await _host.CreateUserAsync("avtor-" + Guid.NewGuid().ToString("N")[..8]);

        await _host.AddReportAsync(userId);
        await _host.AddReportAsync(userId, r => r.Status = ReportStatuses.Resolved);
        await _host.AddReportAsync(userId, r => r.Status = ReportStatuses.Rejected);
    }

    private Task<Report> ReloadAsync(int reportId) =>
        _host.Context.Reports.SingleAsync(r => r.Id == reportId);

    private AdminDashboard AdminPage(string adminId) =>
        _host.CreatePageModel<AdminDashboard>(_host.PrincipalFor(adminId));

    public void Dispose() => _host.Dispose();
}
