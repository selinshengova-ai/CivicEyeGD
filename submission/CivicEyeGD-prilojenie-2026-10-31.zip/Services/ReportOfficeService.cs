using CivicEyeGD.Data;
using Microsoft.EntityFrameworkCore;

namespace CivicEyeGD.Services;

// Единственото място, където общината намесва сигнал: статусът, публичната
// бележка и корекцията на приоритета. Таблото и страницата на сигнала го
// извикват и двете, защото две копия на еднаква логика се разминават.
public sealed class ReportOfficeService
{
    // Бележката се показва публично в историята на сигнала, затова има
    // таван: без него един постър може да напълни страницата.
    public const int MaxCommentLength = 500;

    public enum Outcome
    {
        Saved,
        Unchanged,
        UnknownStatus,
        AdjustmentOutOfRange,
        NotFound
    }

    private readonly ApplicationDbContext _context;

    public ReportOfficeService(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<Outcome> UpdateAsync(
        string? officerUserId,
        int reportId,
        string newStatus,
        string? comment,
        int adjustment)
    {
        if (!ReportStatuses.IsValid(newStatus))
        {
            return Outcome.UnknownStatus;
        }

        // Административната намеса е число 0-10 в края на сметката, а не
        // скрито препращане: без ограничение един клик би сделал който и
        // да е сигнал „висок приоритет".
        if (adjustment < 0 || adjustment > 10)
        {
            return Outcome.AdjustmentOutOfRange;
        }

        var report = await _context.Reports.FindAsync(reportId);
        if (report is null)
        {
            return Outcome.NotFound;
        }

        var changed = false;

        if (report.Status != newStatus)
        {
            var oldStatus = report.Status;
            report.Status = newStatus;

            _context.StatusHistories.Add(new StatusHistory
            {
                ReportId = reportId,
                OldStatus = oldStatus,
                NewStatus = newStatus,
                ChangedByUserId = officerUserId,
                ChangedAt = DateTime.UtcNow,
                Comment = NormalizeComment(comment)
            });

            changed = true;
        }

        if (report.AdminPriorityAdjustment != adjustment)
        {
            report.AdminPriorityAdjustment = adjustment;
            changed = true;
        }

        if (changed)
        {
            await _context.SaveChangesAsync();
        }

        return changed ? Outcome.Saved : Outcome.Unchanged;
    }

    private static string? NormalizeComment(string? comment)
    {
        var trimmed = comment?.Trim();
        if (string.IsNullOrEmpty(trimmed)) return null;

        return trimmed.Length > MaxCommentLength ? trimmed[..MaxCommentLength] : trimmed;
    }
}
